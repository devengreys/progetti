package testing;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class InterazioneDB {

	public InterazioneDB() {
		
	};
	
	public Boolean LOGIN(String username, String password) throws Exception {
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String uname = "postgres";
		String pass = "admin";
		String var1 = username;
		String var2 = password;
		String query = "SELECT count(*) as count FROM public.account WHERE username = ? AND password = ?";
		//String query = "SELECT id, username, password FROM public.account WHERE username = '"+var1+"' AND password = '"+var2+"'";
		Class.forName("org.postgresql.Driver");
		Connection con = DriverManager.getConnection(url, uname, pass);
		PreparedStatement st = con.prepareStatement(query);
		st.setString(1, var1);
		st.setString(2, var2);
		
		ResultSet rs = st.executeQuery();
		rs.next();
		int count = rs.getInt("count");
		
		
		
		  st.close();
		  con.close();
		  if(count>0) {
			  return true;
		  }else {
			  return false;
		  }
		  
		
	}
	
	public Boolean REGISTER(String username, String password) throws Exception {
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String uname = "postgres";
		String pass = "admin";
		String var1 = username;
		String var2 = password;
		String query = "INSERT INTO public.account VALUES (?, ?)";
		Class.forName("org.postgresql.Driver");
		Connection con = DriverManager.getConnection(url, uname, pass);
		PreparedStatement st = con.prepareStatement(query);
		st.setString(1, var1);
		st.setString(2, var2);
		int count = st.executeUpdate();
		
		
		
		st.close();
		con.close();
		if(count!=0) {
			  return true;
		  }else {
			  return false;
		  }
	}

	
}

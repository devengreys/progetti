package testing;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		session.setAttribute("username", null);
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		
		InterazioneDB i = new InterazioneDB();
		
		
		try {
			if(i.LOGIN(user, pass)){
				session.setAttribute("username", user);
			}	
		} catch (Exception e) {
			String nextJSP = "/index.jsp";
			request.setAttribute("risultato", "Accesso Fallito!");
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
			dispatcher.forward(request,response);
		}
		
		if(session.getAttribute("username")==null) {
			String nextJSP = "/index.jsp";
			request.setAttribute("risultato", "Accesso Fallito!");
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
			dispatcher.forward(request,response);
		}else {
			String nextJSP = "/home.jsp";
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
			dispatcher.forward(request,response);
		}
	}

}
